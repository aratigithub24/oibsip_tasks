/**
 * 
 */
/**
 * 
 */
module JAVA_PROJECTS_OASIS {
}